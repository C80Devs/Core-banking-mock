<?php


use App\Models\DeclinedEmailsModel;
use App\Models\Reports;
use App\Models\User;
use Carbon\Carbon;
use Cyberwizard\SendGridMailer\CyberSendGridMailer;
use App\Events\ReportCreatedEvent;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Webklex\IMAP\Facades\Client;


class ProcessIncomingEmails extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'emails:process';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Process incoming emails and log the subject, sender and body';

    public function handle(): int
    {
        $success = 0;
        $client = Client::account('default');
        if (!$client->isConnected()) {
            $client->connect();
        }
        $folder = $client->getFolder('INBOX');
        $messages = $folder->messages()->all()->get() ?? null;

        $logMessages = [];
        $senderEmails = [];

        if (!$messages || $messages->isEmpty()) {
            $info = 'No messages available: ' . Carbon::now();
            $this->info($info);
            Log::info($info);
        } else {
            foreach ($messages as $message) {
                $subject = $message->getSubject();
                $body = $message->getTextBody();
                $returnPath = $message->getHeader()->get('Return-path')->first();

                preg_match('/<([^>]+)>/', $returnPath, $matches);
                $senderEmail = $matches[1] ?? '';

                $user = User::where('email', $senderEmail)->first();

                if ($user) {
                    $member = $user->member();
                    $existingReport = Reports::where('title', $subject)->first();

                    if (!$existingReport) {
                        $reportData = $this->prepareReportData($subject, $body, $member, $user, $message);
                         $message->delete();
                         $report = Reports::create($reportData);
                        event(new ReportCreatedEvent($report, $user));

                        $logMessages[] = "{$user->fullName()}, created an Email report.";
                    } else {

                        $message->delete();
                        $this->sendReportExistEmail($user, $existingReport);
                    }
                } else {

                    $this->sendDeclinedReportEmail($senderEmail);
                }

                $senderEmails[] = $senderEmail;
            }

            $this->info('Sender emails: ' . implode(', ', $senderEmails));
            Log::info('Sender emails: ' . implode(', ', $senderEmails));

            foreach ($logMessages as $logMessage) {
                Log::info($logMessage);
            }
        }

        return $success;
    }

    private function prepareReportData($subject, $body, $member, $user, $message): array
    {
        $tag = 'others';
        $category = ['others'];
        $attachments = [];
        $urgency_level = 'low';
        $deadline = Carbon::now()->addWeeks(2);
        $notes = 'others';
        $reference_materials = [];
        $format = ['pdf', 'docx'];
        $room_id = $member->id;

        $reportData = [
            'title' => $subject,
            'case_details' => $body,
            'tag' => $tag,
            'category' => json_encode($category),
            'attachments' => json_encode($attachments),
            'urgency_level' => $urgency_level,
            'deadline' => $deadline,
            'notes' => $notes,
            'reference_materials' => json_encode($reference_materials),
            'format' => json_encode($format),
            'stage' => 0,
            'room_id' => $room_id,
            'rerun' => false,
            'user_id' => $user->id,
            'summary' => "",
            'assigned' => json_encode([]),
            'agreement' => true,
        ];

        $attachments = $message->getAttachments() ?? [];

        if (!empty($attachments)) {
            $attachmentUrls = [];
            foreach ($attachments as $attachment) {
                $attachmentContent = $attachment->getContent();
                $filename = uniqid() . '_' . $attachment->getFilename();

                Storage::put($filename, $attachmentContent);

                $url = url('/public/api/upload');

                // Simulate upload
                $response = Http::attach('uploads[]', $attachmentContent, $filename)->post($url);

                if ($response->successful()) {
                    $attachmentUrls[] = $response['data'];
                }

                Storage::delete($filename);
            }
            $reportData['attachments'] = json_encode($attachmentUrls);
        }

        return $reportData;
    }



    private function sendReportExistEmail($user, $existingReport): void
    {
        $data = [
            'title' => $existingReport->title,
            'details' => strlen($existingReport->case_details) > 200 ? substr($existingReport->case_details, 0, 200) . '...' : $existingReport->case_details,
            'creator' => $user->fullName(),
            'created_at' => $existingReport->created_at,
        ];

        CyberSendGridMailer::sendEmail(subject: 'Report already exists', to: $user->email, fromEmail: env('MAIL_FROM_ADDRESS'), templatePath: 'email.report-exist', data: $data);
    }

    private function sendDeclinedReportEmail($senderEmail): void
    {
        $existingEmail = DeclinedEmailsModel::where('email', $senderEmail)->first();

        if (!$existingEmail) {
            $data = [
                'url' => env('SIGNUP_URL'),
                'email' => $senderEmail,
            ];
            CyberSendGridMailer::sendEmail(
                subject: 'Report creation declined',
                to: $senderEmail,
                fromEmail: env('MAIL_FROM_ADDRESS'),
                templatePath: 'email.create-report-account',
                data: $data
            );

            DeclinedEmailsModel::create(['email' => $senderEmail]);
        }
    }

}
