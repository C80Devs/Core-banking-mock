<?php

namespace App\Events;

use App\Models\Reports;
use App\Models\User;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class ReportCreatedEvent
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public Reports $report;
    public User $user;

    public function __construct(Reports $report,User $user)
    {
        $this->report = $report;
        $this->user = $user;
    }
}
