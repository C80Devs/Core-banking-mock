<?php

namespace App\Helpers;

use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\View;
use SendGrid\Mail\TypeException;

class SendGridMailer
{
    /**
     * @throws TypeException
     * @throws Exception
     */
    public static function sendEmail(string $subject, string $to, string $fromEmail, string $templatePath, $content = '', array $data = [])
    {
        $email = new \SendGrid\Mail\Mail();
        $email->setFrom($fromEmail, env('APP_NAME'));
        $email->setSubject($subject);
        $email->addTo($to);

        if (count($data) ===0 ) {
            $email->addContent('text/plain', $content);
        } else {
            $mail = View::make($templatePath, $data)->render();
            $email->addContent('text/html', $mail);
        }

        $sendgrid = new \SendGrid(env('SENDGRID_API_KEY'));

        try {
            $response = $sendgrid->send($email);
            return $response;
            Log::info("SendGrid Email Sent - Status Code: {$response->statusCode()}, Headers: " . json_encode($response->headers()) . ", Body: {$response->body()}");
        } catch (Exception $e) {
            Log::error('Exception caught: ' . $e->getMessage());
            throw $e;
        }
    }


}
