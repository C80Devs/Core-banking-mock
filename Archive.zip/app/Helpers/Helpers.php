<?php


namespace App\Helpers;

use App\Models\AccountModel;
use App\Models\Transactions;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\HttpFoundation\JsonResponse;

class Helpers
{
    /**
     * Generate a random password.
     *
     * @param int $length Length of the password
     * @return string Generated password
     */

    public static function generateUserCode(string $name, string $lastname): string
    {
        $code = strtolower(substr($name, 0, 1) . $lastname);
        $i = 1;
        while (User::where('code', $code)->exists()) {
            $code = $code . $i;
            $i++;
        }

        return $code;
}

    public static function generateAccountNumber(): int
    {
        $accountNumber = mt_rand(10000000000, 99999999999);
        while (AccountModel::where('account_number', $accountNumber)->exists()) {
            $accountNumber = mt_rand(10000000000, 999999999999);
        }

        return $accountNumber;
    }


    public static function generateReferenceNumber(int $length = 20): string
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $referenceNumber = '';
        for ($i = 0; $i < $length; $i++) {
            $referenceNumber .= $characters[rand(0, strlen($characters) - 1)];
        }

        while (Transactions::where('reference', $referenceNumber)->exists()) {
            // If it exists, generate a new random reference number
            $referenceNumber = '';
            for ($i = 0; $i < $length; $i++) {
                $referenceNumber .= $characters[rand(0, strlen($characters) - 1)];
            }
        }
        return $referenceNumber;
    }
    public static function passwordGenerate(int $length = 8): string
    {
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $password = '';
        for ($i = 0; $i < $length; $i++) {
            $password .= $chars[rand(0, strlen($chars) - 1)];
        }
        return $password;
    }

    public static function makeDir(): void
    {
        $directoryPath = storage_path('app/public/photos');
        if (!file_exists($directoryPath)) {
            mkdir($directoryPath, 0755, true);
        }

    }

    public  static function formatDate($date): string
    {
        return Carbon::parse($date)->format('F j, Y');
    }

    public static function validateEmails($email): bool
    {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }


    /**
 * Check the user's account status and return a response if necessary.
 *
 * @param int $status
 * @return JsonResponse|null
 */
    public static function checkAccountStatus($status): ?JsonResponse
    {
        try {
            global $response;

            if ($status === 0) {
                $response = response()->json([
                    'status' => false,
                    'message' => 'Unauthorized. Your account has been de-activated.',
                ], 401);
            } elseif ($status === 2) {
                $response = response()->json([
                    'status' => false,
                    'message' => 'Your account has been suspended.',
                ], 401);
            } elseif ($status === null) {
                $response = response()->json([
                    'status' => false,
                    'message' => 'Your account has not been activated.',
                ],401);
            }

            return $response;
        } catch (\Exception $exception) {
            return $response = response()->json([
                'status' => false,
                'message' => 'An error has occurred.',
            ],500);
        }
    }
}
