<?php

namespace App\Listeners;

use App\Events\ReportCreatedEvent;
use App\Models\NotificationModel;
use Cyberwizard\SendGridMailer\CyberSendGridMailer;
use Illuminate\Contracts\Queue\ShouldQueue;

class ReportCreatedListener implements ShouldQueue
{
    public function __construct()
    {

    }

    public function handle(ReportCreatedEvent $event): void
    {
        $report = $event->report;
        $user = $event->user;
        $data = [
            'fullname' => $user->fullName(),
            'reportId' => $report->id,
            'reportTitle' => $report->title,
            'reportDetails' => strlen($report->case_details) > 200 ? substr($report->case_details, 0, 200) : $report->case_details,
            'createdAt' => $report->created_at,
            'attachment' => $report->attachments ? 'This report has attachments.' : 'N/A',
        ];

        if ($report->attachments) {
            $data['attachments'] = 'This report has ' . count(json_decode($report->attachments)) . ' attachment(s).';
        }

        $message = "{$user->firstname}, created a report.";

        NotificationModel::createNotification($report->room_id, $user->id, $message, $report->id, 'New Report created.');

        CyberSendGridMailer::sendEmail(subject: 'Report created', to: $user->email, fromEmail: env('MAIL_FROM_ADDRESS'), templatePath: 'email.report-created', data: $data);

    }
}
