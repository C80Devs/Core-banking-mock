<?php

namespace App\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class FileController
{
    public static function uploadFiles(Request $request): JsonResponse
    {

        try {


            if ($request->has('uploads')) {
                $attachmentUrls = [];

                foreach ($request->file('uploads') as $attachment) {


                    if ($attachment->isValid()) {
                        $originalFilename = $attachment->getClientOriginalName();

                        $timestamp = now()->timestamp;

                        $filename = $timestamp . '_' . $originalFilename;
                        $path = $attachment->storeAs('uploads', $filename, 's3');

                        // Make the uploaded file publicly accessible
                        Storage::disk('s3')->setVisibility($path, 'public');

                        $url = Storage::disk('s3')->url($path);
                        $attachmentUrls[] = $url;
                    } else {
                        return response()->json([
                            'status' => false,
                            'message' => 'Invalid file(s) provided.',
                        ], 422);
                    }
                }

                if (count($attachmentUrls) === 1) {
                    return response()->json([
                        'status' => true,
                        'message' => 'File uploaded successfully',
                        'data' => $attachmentUrls,
                    ]);
                } else {
                    return response()->json([
                        'status' => true,
                        'message' => 'Files uploaded successfully',
                        'data' => $attachmentUrls,
                    ]);
                }
            } else {
                return response()->json([
                    'status' => false,
                    'message' => 'No files provided.',
                ], 422);
            }

        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'No files provided.'. $e->getMessage(),
            ], 422);
        }
    }
}
