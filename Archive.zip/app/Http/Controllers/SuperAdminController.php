<?php
 namespace App\Http\Controllers;
use App\Helpers\Helpers;
use App\Models\MembersModel;
use App\Models\Reports;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use Illuminate\Validation\Rule;

class SuperAdminController extends Controller
{
    public function superAdminDashboard(): JsonResponse
    {

        return response()->json([
            'status' => true,
            'data' => ['totalReportsCount' => Reports::getTotalReportCounts(),
                        'workstations' =>   User::activeMembers(),
                        'completed' => Reports::completedRequests(),
                        'ongoing' => Reports::ongoingRequests(),
                        'declined' => Reports::declinedRequests(),
                        'new_aides' => User::newAides(),
                        'topWorkstations' =>User::topWorkstations()

            ],
        ], 200);


    }

    public function superSmallAdminDashboard(): JsonResponse
    {
        $totalRequestsCount = Reports::totalRequestsCount();
        $activeWorkStation = User::activeWorkStationCount();
        $totalAides = User::totalAidesCount();
        $theSenate = User::senateCount();
        $theReps = User::repsCount();

        return response()->json([
            'status' => true,
            'data' => [
                'totalReportsCount' => $totalRequestsCount,
                'total_rooms' => $activeWorkStation,
                'the_senate' => $theSenate,
                'the_reps' => $theReps,
                'total_aides' => $totalAides,
            ],
        ], 200);
    }


    public function moveUser(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'la_id' => 'required|exists:users,id',
            'old_user_id' => 'required|exists:users,id',
            'new_user_id' => 'required|exists:users,id',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => $validator->errors()->first(),
            ], 422);
        }

        $la_id = $request->input('la_id');
        $oldUserId = $request->input('old_user_id');
        $newUserId = $request->input('new_user_id');

        // Check if all users exist
        $oldUser = User::find($oldUserId);
        $newUser = User::find($newUserId);
        $la_id = User::find($la_id);

        if (!$oldUser || !$newUser) {
            return response()->json([
                'status' => false,
                'message' => 'Old or new user not found.',
            ], 404);
        }


        if (!$la_id) {
            return response()->json([
                'status' => false,
                'message' => 'LA not found.',
            ], 404);
        }

        $laCount = MembersModel::where('user_id', $newUserId)->count();
        if ($laCount >= 5) {
            return response()->json([
                'status' => false,
                'message' => 'Cannot move, The new user already has the maximum number of LA associations (5).',
            ], 422);
        }

        $oldMember = MembersModel::where('user_id', $oldUserId)
            ->where('la_id',$la_id)
            ->first();

        if (!$oldMember) {
            return response()->json([
                'status' => false,
                'message' => 'LA not registered to old user',
            ], 404);
        }

        $oldMember->user_id = $newUserId;
        $oldMember->save();

        return response()->json([
            'status' => true,
            'message' => 'User association moved successfully to member with ID ' . $newUser->id,
        ]);
    }

    public function generateRegistrationLink(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'code' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'code' => 422,
                'message' => $validator->errors()->first(),
            ], 422);
        }

        $code = $request->input('code');
        $user = User::where('code', $code)->first();

        if (!$user) {
            return response()->json([
                'status' => false,
                'code' => 404,
                'message' => 'Link: User not found.',
            ], 404);
        }

        $registrationLink = url("/register?userId={$user->id}");

        return response()->json([
            'status' => true,
            'code' => 200,
            'message' => 'Registration link generated successfully.',
            'data' => ['registration_link' => $registrationLink],
        ], 200);
    }

    public function getUserByID(int $id): JsonResponse
    {
        // Find the user by code
        $user = User::find($id);

        if (!$user) {
            return response()->json([
                'status' => false,
                'code' => 404,
                'message' => 'User not found.',
            ], 404);
        }

        return response()->json([
            'status' => true,
            'code' => 200,
            'message' => 'User details retrieved successfully.',
            'data' => $user,
        ], 200);
    }

    public function fetchAides(Request $request): JsonResponse
    {
        $perPage = $request->input('per_page', 10);
        $page = $request->input('page', 1);

        $users = User::where('is_la', true)
            ->where('superadmin', false)
            ->paginate($perPage, ['*'], 'page', $page);

        return response()->json([
            'status' => true,
            'code' => 200,
            'message' => 'Aides retrieved successfully',
            'data' => $users,
        ]);
    }

    public function getUsers(Request $request): JsonResponse
    {
        $perPage = $request->input('per_page', 10);
        $page = $request->input('page', 1);

        $users = User::where('is_la', false)
            ->where('superadmin', false)
            ->where('active', true)
            ->paginate($perPage, ['*'], 'page', $page);

        return response()->json([
            'status' => true,
            'code' => 200,
            'message' => 'Users retrieved successfully',
            'data' => $users,
        ], 200);
    }



    public function addUser(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'firstname' => 'required|string',
            'middlename' => 'nullable|string',
            'lastname' => 'required|string',
            'email' => ['required', 'string', 'unique:users,email', function ($attribute, $value, $fail) {
                if (!Helpers::validateEmails($value)) {
                    $fail('The ' . $attribute . ' must be a valid email address.');
                }
            }],

            'bio' => 'nullable|string',
            'party' => 'required|string',
            'assembly' => 'required',
            'leg_house' => 'required|string',
            'position' => 'required|string',
            'phone' => 'required|string',
            'photo' => 'nullable|url',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'code' => 422,
                'message' => $validator->errors()->first(),
            ], 422);
        }

        $newUser = User::create([
            'firstname' => $request->firstname,
            'middlename' => $request->middlename,
            'lastname' => $request->lastname,
            'email' => $request->email,
            'password' => Hash::make(Helpers::passwordGenerate()), // Generating random password
            'code' => Helpers::generateUserCode($request->input('firstname'), $request->input('lastname')) ,
            'is_la' => false,
            'level' => 0,
            'phone' => $request->phone,
            'assembly' => $request->assembly,
            'party' => $request->party ?? '',
            'leg_house' => $request->leg_house ?? '',
            'position' => $request->position ?? '',
            'bio' => $request->bio ?? '',
            'photo' => $request->photo ?? '',
        ]);

        return response()->json([
            'status' => true,
            'code' => 201,
            'message' => 'User registered successfully',
            'data' => $newUser,
        ], 201);
    }


public function activation(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|integer|exists:users,id',
            'active' => 'required|boolean',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'code' => 422,
                'message' => $validator->errors()->first(),
            ], 422);
        }

        $userId = $request->input('user_id');
        $active = $request->input('active');

        $user = User::find($userId);

        if (!$user) {
            return response()->json([
                'status' => false,
                'code' => 404,
                'message' => 'Activation: User not found..',
            ], 404);
        }

            $user->active = $active ? true : false;
            $user->save();

            return response()->json([
                'status' => true,
                'code' => 200,
                'message' => $active ? 'User activated successfully' : 'User deactivated successfully',
            ], 200);

    }


    public function suspension(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|integer|exists:users,id',
            'suspend' => 'required|boolean',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'code' => 422,
                'message' => $validator->errors()->first(),
            ], 422);
        }

        $userId = $request->input('user_id');
        $active = $request->input('suspend');

        $user = User::find($userId);

        if (!$user) {
            return response()->json([
                'status' => false,
                'code' => 404,
                'message' => 'Suspension: User not found..',
            ], 404);
        }

        $user->active = $active ? true : false;
        $user->save();

        return response()->json([
            'status' => true,
            'code' => 200,
            'message' => $active ? 'User Suspended successfully' : 'Suspension lifted successfully',
        ], 200);

    }


    public function rooms(): JsonResponse
    {
        $users = DB::table('users')
            ->where('is_la', false)
            ->where('superadmin', false)
            ->get();

        $userData = [];

        foreach ($users as $user) {
            $userMembers = DB::table('members')
                ->where('user_id', $user->id)
                ->get();

            $requestsCount = 0;
            $teamMembersCount = count($userMembers);

            foreach ($userMembers as $member) {
                $reports = DB::table('reports')
                    ->where('user_id', $member->la_id)
                    ->get();

                $requestsCount += $reports->count();
            }

            $userData[] = [
                'room_id' => $user->id,
                'room_name' => $user->firstname . ' ' . $user->lastname,
                'requests' => $requestsCount,
                'members' => $teamMembersCount,
            ];
        }
        return response()->json($userData);
    }

    public function teams(): JsonResponse
    {
        $users = User::where('superadmin', false)
            ->where('is_la', false)
            ->get();

        $responseData = [];

        foreach ($users as $user) {
            $members = MembersModel::where('user_id', $user->id)->get();

            $userData = $user->toArray();
            unset($userData['password']);

            foreach ($members as $member) {
                $aideUser = User::find($member->la_id);
                // Exclude superadmin and is_la from the response
                if ($aideUser && !$aideUser->superadmin) {
                    $aideLevel = '';
                    switch ($member->la_level) {
                        case 1:
                            $aideLevel = 'LEGISLATIVE AIDE';
                            break;
                        case 2:
                            $aideLevel = 'SENIOR LEGISLATIVE AIDE';
                            break;
                        default:
                            $aideLevel = 'LEGISLATIVE MEMBER  ';
                            break;
                    }

                    $aide_status = "";
                    switch ($aideUser->active) {
                        case 1:
                            $aide_status = 'Activated';
                            break;
                        case 0:
                            $aide_status = 'Not Activated';
                            break;
                        case 2:
                            $aide_status = 'Suspended';
                            break;
                    }

                    $responseData[] = [
                        'name_of_aide' => $aideUser->firstname . ' ' . $aideUser->lastname,
                        'legislative_member' => $userData['firstname'] . ' ' . $userData['lastname'],
                        'aide_level' => $aideLevel,
                        'aide_status' => $aide_status,
                        'aide_id' => $aideUser->id,
                        'aide_date_created' => Helpers::formatDate($member->created_at)
                    ];
                }
            }
        }

        return response()->json([
            'status' => true,
            'data' => $responseData
        ]);
    }


    public function roomOwnerDetails(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|exists:users,id',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'code' => 422,
                'message' => $validator->errors()->first(),
            ], 422);
        }

        $userId = $request->input('user_id');

        $memberUserIds = MembersModel::where('user_id', $userId)->pluck('la_id');

        $userDetails = User::whereIn('id', $memberUserIds)->get();
        $Reports = Reports::whereIn('user_id', $memberUserIds)->get();

        return response()->json([
            'status' => true,
            'users' => $userDetails,
            'reports' => $Reports,
        ]);
    }

    public function deleteUser($id): JsonResponse
    {
        $validator = Validator::make(['id' => $id], [
            'id' => 'required|exists:users,id',
        ]);


        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'code' => 422,
                'message' => $validator->errors()->first(),
            ], 422);
        }

        $user = User::find($id);

        if (!$user) {
            return response()->json([
                'status' => false,
                'code' => 404,
                'message' => 'User not found.',
            ], 404);
        }

        if ($user->is_la) {
            MembersModel::where('la_id', $id)->delete();
        }

        if ($user->delete()) {
            return response()->json([
                'status' => true,
                'code' => 200,
                'message' => 'User deleted successfully',
            ], 200);
        }

        return response()->json([
            'status' => false,
            'code' => 500,
            'message' => 'Failed to delete user',
        ], 500);
    }

    public function editUser(Request $request, $id): JsonResponse
    {

        $user = User::find($id);
        if (!$user) {
            return response()->json([
                'status' => false,
                'code' => 404,
                'message' => 'User not found',
            ], 404);
        }

        $validator = Validator::make($request->all(), [
            'firstname' => 'required|string',
            'lastname' => 'required|string',
            'email' => [
                'required',
                'string',
                'email',
                Rule::unique('users')->ignore($id),
                function ($attribute, $value, $fail) {
                    if (!Helpers::validateEmails($value)) {
                        $fail('The ' . $attribute . ' must be a valid email address.');
                    }
                }
            ],
            'code' => 'nullable|string',
            'level' => 'nullable|integer',
            'active' => 'nullable|boolean',
            'phone' => 'nullable|string',
            'party' => 'nullable|string',
            'assembly' => 'required|integer',
            'leg_house' => 'nullable|string',
            'position' => 'nullable|string',
            'bio' => 'nullable|string',
            'photo' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'code' => 422,
                'message' => $validator->errors()->first(),
            ], 422);
        }


        $fieldsToUpdate = $request->only([
            'firstname', 'middlename', 'lastname', 'email', 'code', 'level',
             'phone', 'party', 'assembly', 'leg_house', 'position', 'bio', 'photo'
        ]);

        foreach ($fieldsToUpdate as $key => $value) {
            if (!is_null($value)) {
                $user->$key = $value;
            }
        }

        $user->save();

        return response()->json([
            'status' => true,
            'code' => 200,
            'message' => 'User updated successfully',
            'data' => $user,
        ]);
    }
}
