<?php

namespace App\Http\Controllers;

use App\Models\NotificationModel;
use App\Models\Reports;
use App\Models\User;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Webklex\IMAP\Facades\Client;

class EmailController extends Controller
{

}
