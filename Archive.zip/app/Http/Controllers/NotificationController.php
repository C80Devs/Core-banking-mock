<?php

namespace App\Http\Controllers;

use App\Models\NotificationModel;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class NotificationController extends Controller
{
    public function updateSeenStatus(int $id): JsonResponse
    {

        $validator = Validator::make(['id'=>$id], [
            'id' => 'required|integer|exists:notification,id',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => $validator->errors()->first(),
            ], 422);
        }

        $notification = NotificationModel::where('id',$id)
            ->where('la_id',Auth::id())->first();

        if (!$notification) {
            return response()->json([
                'status' => false,
                'message' => 'Notification not found.'
            ], 404);
        }

        $notification->seen = true;
        $notification->save();

        return response()->json([
            'status' => true,
            'message' => 'Notification seen status updated.'
        ]);
    }
}
