<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class CheckAbilities
{
    public function handle(Request $request, Closure $next, ...$abilities)
    {
        $user = $request->user();

        foreach ($abilities as $ability) {
            if ($user->tokenCan($ability)) {
                return $next($request);
            }
        }

        return response()->json([
            'status' => false,
            'code' => 403,
            'message' => 'Unauthorized. Insufficient privileges.',
        ], 403);
    }
}
