<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Cache\RateLimiter;
use Illuminate\Http\Exceptions\ThrottleRequestsException;
use Illuminate\Routing\Middleware\ThrottleRequests;
use Symfony\Component\HttpFoundation\Response;

class CustomThrottle extends ThrottleRequests
{
    protected function buildException($request, $key, $maxAttempts, $responseCallback = null): ThrottleRequestsException
    {
        $retryAfter = $this->limiter->availableIn($key);

        $response = response()->json([
            'status' => false,
            'message' => 'Too Many Attempts.',
            'retry_after' => $retryAfter
        ], Response::HTTP_TOO_MANY_REQUESTS);

        return new ThrottleRequestsException('Too Many Attempts.', null, $response->headers->all());
    }
}
