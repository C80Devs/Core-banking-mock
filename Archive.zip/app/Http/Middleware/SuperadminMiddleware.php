<?php

namespace App\Http\Middleware;

use Closure;
use Exception;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Illuminate\Http\Request;

class SuperadminMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure $next
     * @return mixed
     */
public string $secret = '123456';
public string $algo = 'HS512';


    public function handle(Request $request, Closure $next): mixed
    {
        $token = $request->bearerToken();

        if (!$token) {
            return response()->json([
                'status' => false,
                'code' => 401,
                'message' => 'Unauthorized. Token is missing or invalid.',
            ], 401);
        }

        try {
            $decodedToken  =JWT::decode($token, new Key($this->secret, $this->algo));


        } catch (\Exception $e) {
            $decodedToken = null ;
            return response()->json([
                'status' => false,
                'code' => 401,
                'data' =>$decodedToken,
                'message' => 'Unauthorized. Token is invalid.' .$e->getMessage(),
            ], 401);
        }

        if (isset($decodedToken->data->superuser) && $decodedToken->data->superuser === 1) {
            return $next($request);
        }

        // User is not a superuser, deny access
        return response()->json([
            'status' => false,
            'code' => 403,
            'message' => 'Unauthorized. Only superusers can access this resource.',
        ], 403);
    }

    /*   public function handle(Request $request, Closure $next)
       {
           if ($request->user() && $request->user()->superadmin) {
               return $next($request);
           }

           return response()->json([
               'status' => false,
               'code' => 403,
               'message' => 'Unauthorized. Only superadmins can access this resource.',
           ], 403);
       }*/
}
