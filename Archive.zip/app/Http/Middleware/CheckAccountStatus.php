<?php

namespace App\Http\Middleware;

use App\Models\AccountModel;
use Closure;
use Illuminate\Http\Request;

class CheckAccountStatus
{
    public function handle(Request $request, Closure $next)
    {
        $accountNumber = $request->input('account_number');

        $account = AccountModel::where('account_number', $accountNumber)->first();

        if (!$account || !$account->can_debit) {
            return response()->json([
                'status' => false,
                'message' => 'Account not found or cannot be debited'
            ]);
        }

        return $next($request);
    }
}
