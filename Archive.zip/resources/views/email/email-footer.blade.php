<p>If you have any questions or need assistance, please contact our {{env('APP_NAME')}} team at <a
        href="mailto:{{env('MAIL_FROM_ADDRESS')}}">{{env('MAIL_FROM_ADDRESS')}}</a>.</p>
<p>Thank you,</p>
<p>{{env('APP_NAME')}} Team</p>
